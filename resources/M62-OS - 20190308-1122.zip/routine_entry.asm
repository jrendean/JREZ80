;************************************
; M62-OS
;************************************
; routine_entry.asm - M62-OS Jump table
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************

; Standard I/O Routines
PUTC:					JP $5000			; Write Character from A to standard output
PUTS:					JP $5003			; Write ASCIIZ String pointed to by HL to standard output
GETC:					JP $5006			; Read Character from standard input into A
TO_UPPER:				JP $5009			; Make the lower case character in A upper case
PRINT_NEW_LINE:			JP $500C			; Send new line characters (CR+LF) to standard output
CHAR_ISHEX:				JP $500F			; C Flag is set if the character in A is hex
GET_HEX_NIB:			JP $5012			; Get single hex digit, store in lower nibble of A from standard input
GET_HEX_BYTE			JP $5015			; Get hex byte, stores in A from standard input
GET_HEX_WORD:			JP $5018			; Get hex word, stores in HL from standard input
PRINT_HEX_NIB:			JP $501B			; Send hex character of lower nibble of A to standard output
PRINT_HEX_BYTE:			JP $501E			; Send hex character pairs of value in A to standard output
PRINT_HEX_WORD:			JP $5021			; Send 4 character hex word in HL to standard output

; String Routines

STRCMP:					JP $5024			; Compare string (HL) with (DE), set Z if match
STRISHEX:				JP $5027			; Checks if a string (HL) is a valid hex value, set Z if it is
STRISNUM:				JP $502A			; Checks if a string (HL) is a valid dec value, set Z if it is
STRLEN:					JP $502D			; Returns B as the length of string (HL)
STRSUBCNT:				JP $5030			; Counts the number of substrings seperated with specificed seperator
STRHEXVAL:				JP $5033			; Gets the value of a hex number string (Not implemented yet)
STRDECVAL:				JP $5036			; Gets the value of a decimal number string (Not implemented yet)

; UART Routines
UART_INIT:				JP $5039			; Initialize the UART
UART_PRNT_STR:			JP $503C			; Print String directly to UART
UART_TX_RDY:			JP $503F			; Is there a byte waiting in the UART buffer?
UART_TX:				JP $5042			; Receive a byte from the UART (Wait for a byte if non available)
UART_RX_RDY:			JP $5045			; Is there a UART buffer ready for me to send it a byte?
UART_RX:				JP $5048			; Semd a byet to the UART (wait if buffer is full)

; Delay Routine
loopDELAY:  			JP $504B			; Perform a delay. Load delay value from os_defs.asm into HL before calling.

; Math Routines
MULT_8:					JP $504E 			; Multiply 8-bit values (H*E = HL)
MULT_12: 				JP $5051 			; Multiply 8-bit value with a 16-bit value (A*DE = HL)
MULT_16: 				JP $5054 			; Multiply 16-bit values (with 16-bit result) BC*DE = HL
MULT_32: 				JP $5057 			; Multiply 16-bit values (with 32-bit result) BC*DE = BCHL
DIV_8:					JP $505A			; Divide 8-bit values E/C = A (B rest)
DIV_16:					JP $505D			; Divide 16-bit values (with 16-bit result) BC/DE = BC (HL rest)
SQRT_16:				JP $5060			; Square root of 16-bit value (HL = value, D = result)

; OS Routines
RETURN_TO_OS			JP $5063			; Return back to the CLI

