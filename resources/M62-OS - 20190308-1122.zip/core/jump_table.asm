;************************************
; M62-OS
;************************************
; jump_table.asm - M62-OS Jump table
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************

; Standard I/O Routines
PUTC:					JP _PUTC			; Write Character from A to standard output
PUTS:					JP _PUTS			; Write ASCIIZ String pointed to by HL to standard output
GETC:					JP _GETC			; Read Character from standard input into A
TO_UPPER:				JP _TO_UPPER		; Make the lower case character in A upper case
PRINT_NEW_LINE:			JP _PRINT_NEW_LINE	; Send new line characters (CR+LF) to standard output
CHAR_ISHEX:				JP _CHAR_ISHEX		; C Flag is set if the character in A is hex
GET_HEX_NIB:			JP _GET_HEX_NIB		; Get single hex digit, store in lower nibble of A from standard input
GET_HEX_BYTE			JP _GET_HEX_BYTE	; Get hex byte, stores in A from standard input
GET_HEX_WORD:			JP _GET_HEX_WORD	; Get hex word, stores in HL from standard input
PRINT_HEX_NIB:			JP _PRINT_HEX_NIB	; Send hex character of lower nibble of A to standard output
PRINT_HEX_BYTE:			JP _PRINT_HEX_BYTE	; Send hex character pairs of value in A to standard output
PRINT_HEX_WORD:			JP _PRINT_HEX_WORD	; Send 4 character hex word in HL to standard output

; String routines
STRCMP:					JP _STRCMP			; Compare string (HL) with (DE), set Z if match
STRISHEX:				JP _STRISHEX		; Checks if a string (HL) is a valid hex value, set Z if it is
STRISNUM:				JP _STRISNUM		; Checks if a string (HL) is a valid dec value, set Z if it is
STRLEN:					JP _STRLEN			; Returns B as the length of string (HL)
STRSUBCNT:				JP _STRSUBCNT		; Counts the number of substrings seperated with specificed seperator
STRHEXVAL:				JP _STRHEXVAL		; Gets the value of a hex number string (Not implemented yet)
STRDECVAL:				JP _STRDECVAL		; Gets the value of a decimal number string (Not implemented yet)

; UART Routines
UART_INIT:				JP _UART_INIT		; Initialize the UART
UART_PRNT_STR:			JP _UART_PRNT_STR	; Print String directly to UART
UART_TX_RDY:			JP _UART_TX_RDY		; Is there a byte waiting in the UART buffer?
UART_TX:				JP _UART_TX			; Receive a byte from the UART (Wait for a byte if non available)
UART_RX_RDY:			JP _UART_RX_RDY		; Is there a UART buffer ready for me to send it a byte?
UART_RX:				JP _UART_RX			; Semd a byet to the UART (wait if buffer is full)

; Delay Routine
loopDELAY:  			JP _loopDELAY		; Perform a delay. Load delay value from os_defs.asm into HL before calling.

; Math Routines
MULT_8:					JP _MULT_8 			; Multiply 8-bit values (H*E = HL)
MULT_12: 				JP _MULT_12 		; Multiply 8-bit value with a 16-bit value (A*DE = HL)
MULT_16: 				JP _MULT_16 		; Multiply 16-bit values (with 16-bit result) BC*DE = HL
MULT_32: 				JP _MULT_32 		; Multiply 16-bit values (with 32-bit result) BC*DE = BCHL
DIV_8:					JP _DIV_8			; Divide 8-bit values E/C = A (B rest)
DIV_16:					JP _DIV_16			; Divide 16-bit values (with 16-bit result) BC/DE = BC (HL rest)
SQRT_16:				JP _SQRT_16			; Square root of 16-bit value (HL = value, D = result)

; OS Routines
RETURN_TO_OS			JP CMD_LINE			; Return back to the CLI