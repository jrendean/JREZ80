;************************************
; M62-OS
;************************************
; romfs.asm - ROMFS - ROM FileSystem
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************

; ROMFS header

; Offset | Size (hex) | Size (dec) |    Name    | Description
;--------+------------+------------+------------+----------------------------------------------------------
;  $00   |    $05     |      5     | Ident      | "ROMFS"      
;  $05   |    $01     |      1     | Type       | Device type  
;  $06   |    $02     |      2     | Ver        | Highver, Lowver
;  $08   |    $01     |      1     | Attribs    | [x|x|x|x|x|x|App(0)/Data(1)|WriteEnable]
;  $09   |    $01     |      1     | Size       | Number of 16K pages on the device
;  $0A   |    $01     |      1     | Page       | Page this header is on
;  $0B   |    $14     |     20     | Label      | Device label, null terminated              
;  $20   |    $08     |      8     | Filename   | Applicate/Data filename, null terminate 
;  $28   |    $D8     |    216     | Desc       | Optional description, must be null terminated either way
;--------+------------+------------+------------+----------------------------------------------------------

RFS_IDENT:		.EQU	BANK_2
RFS_TYPE:		.EQU	BANK_2 + $05
RFS_VER:		.EQU	BANK_2 + $06
RFS_ATTRIBS:	.EQU	BANK_2 + $08
RFS_SIZE:		.EQU	BANK_2 + $09
RFS_PAGE:		.EQU	BANK_2 + $0A
RFS_LABEL:		.EQU	BANK_2 + $0B
RFS_FILENAME:	.EQU	BANK_2 + $0A
RFS_DESC:		.EQU	BANK_2 + $0B

; device will be at BANK_2


;**********************************************************************************
; RFS_CHECK	- Checks if the current device is ROMFS
;**********************************************************************************
; Entry: 	
;			none
; Exit: 	
;			Z flag is set if it is ROMFS, clear otherwise
;*****************************************************************************
RFS_CHECK:		LD		HL, BANK_2
				LD		A, (HL)
				CP		'R'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'O'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'M'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'F'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'S'
				RET
