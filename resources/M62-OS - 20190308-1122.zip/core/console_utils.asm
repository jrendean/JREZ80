;**********************************************
; M62 BIOS
;**********************************************
; console_utils.asm - General utility routines
;**********************************************


;***************************************************************************
;TO_UPPER
;Function: Convert character in Accumulator to upper case
;***************************************************************************
; By Matt Cook
; https://z80project.wordpress.com/author/matthewcook6254/
;***************************************************************************		
_TO_UPPER:       
			CP      'a'             	; Nothing to do if not lower case
            RET     C
            CP      'z' + 1         	; > 'z'?
            RET     NC              	; Nothing to do, either
            AND     $5F             	; Convert to upper case
            RET		
			

;***************************************************************************
;CHAR_ISHEX
;Function: Checks if value in A is a hexadecimal digit, C flag set if true
;***************************************************************************		
; By Matt Cook
; https://z80project.wordpress.com/author/matthewcook6254/
;***************************************************************************		
_CHAR_ISHEX:         
										;Checks if Acc between '0' and 'F'
			CP      'F' + 1       		;(Acc) > 'F'? 
            RET     NC              	;Yes - Return / No - Continue
            CP      '0'             	;(Acc) < '0'?
            JP      NC,_CHAR_ISHEX_1 	;Yes - Jump / No - Continue
            CCF                     	;Complement carry (clear it)
            RET
_CHAR_ISHEX_1:       
										;Checks if Acc below '9' and above 'A'
			CP      '9' + 1         	;(Acc) < '9' + 1?
            RET     C               	;Yes - Return / No - Continue (meaning Acc between '0' and '9')
            CP      'A'             	;(Acc) > 'A'?
            JP      NC,_CHAR_ISHEX_2 	;Yes - Jump / No - Continue
            CCF                     	;Complement carry (clear it)
            RET
_CHAR_ISHEX_2:        
										;Only gets here if Acc between 'A' and 'F'
			SCF                     	;Set carry flag to indicate the char is a hex digit
            RET
			
			
_CLRSCR:
			LD		HL, CLEAR_STRING
			CALL	_PUTS
			LD		HL, HOME_STRING
			CALL	_PUTS
			RET