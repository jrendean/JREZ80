;************************************
; M62-OS
;************************************
; console.asm - Console assembly file
;************************************
; For an alternate console standard I/O, create a new library but make
;  sure you implements all the routines names in this file.
;
; Much taken from Matt Cook's code

;***************************************************************************
;GET_CHAR
;Function: Get ASCII character from user into Accumulator
;***************************************************************************			
_GETC:
			CALL	_UART_RX				;Get char into Acc
			RET
			
;***************************************************************************
;GET_HEX_NIBBLE
;Function: Translates char to HEX nibble in bottom 4 bits of A
;***************************************************************************
_GET_HEX_NIB:      
			CALL	_GETC
			CALL	_TO_UPPER			;Character has to be upper case
            CALL    _CHAR_ISHEX      	;Is it a hex digit?
            JP      NC,_GET_HEX_NIB  	;Yes - Jump / No - Continue
			CALL    _PUTC
			CP      '9' + 1         	;Is it a digit less or equal '9' + 1?
            JP      C,_GET_HEX_NIB_1 	;Yes - Jump / No - Continue
            SUB     $07             	;Adjust for A-F digits
_GET_HEX_NIB_1:                
			SUB     '0'             	;Subtract to get nib between 0->15
            AND     $0F             	;Only return lower 4 bits
            RET	
				
;***************************************************************************
;GET_HEX_BTYE
;Function: Gets HEX byte into A
;***************************************************************************
_GET_HEX_BYTE:
            CALL    _GET_HEX_NIB			;Get high nibble
            RLC     A					;Rotate nibble into high nibble
            RLC     A
            RLC     A
            RLC     A
            LD      B,A					;Save upper four bits
            CALL    _GET_HEX_NIB			;Get lower nibble
            OR      B					;Combine both nibbles
            RET				
			
;***************************************************************************
;GET_HEX_WORD
;Function: Gets two HEX bytes into HL
;***************************************************************************
_GET_HEX_WORD:
			PUSH    AF
            CALL    _GET_HEX_BYTE		;Get high byte
            LD		H,A
            CALL    _GET_HEX_BYTE    	;Get low byte
            LD      L,A
            POP     AF
            RET


;***************************************************************************
;PRINT_STRING
;Function: Prints string to terminal program
;***************************************************************************
_PUTS:
			JP		_UART_PRNT_STR
;			CALL    UART_PRNT_STR
;			RET
			
;***************************************************************************
;PRINT_CHAR
;Function: Get upper case ASCII character from Accumulator to UART
;***************************************************************************			
_PUTC:
			CALL	_UART_TX				;Echo character to terminal
			RET			
			
;***************************************************************************
;PRINT_NEW_LINE
;Function: Prints carriage return and line feed
;***************************************************************************			

NEW_LINE_STRING: 	.BYTE "\r\n",EOS

_PRINT_NEW_LINE:
			PUSH	HL
			LD 		HL,NEW_LINE_STRING			
			CALL    _PUTS			
			POP		HL
			RET
			
;***************************************************************************
;PRINT_HEX_NIB
;Function: Prints a low nibble in hex notation from Acc to the serial line.
;***************************************************************************
_PRINT_HEX_NIB:
			PUSH 	AF
            AND     $0F             	;Only low nibble in byte
            ADD     A,'0'             	;Adjust for char offset
            CP      '9' + 1         	;Is the hex digit > 9?
            JP      C,_PRINT_HEX_NIB_1	;Yes - Jump / No - Continue
            ADD     A,'A' - '0' - $0A 	;Adjust for A-F
_PRINT_HEX_NIB_1:
			CALL	_PUTC        	;Print the nibble
			POP		AF
			RET
				
;***************************************************************************
;PRINT_HEX_BYTE
;Function: Prints a byte in hex notation from Acc to the serial line.
;***************************************************************************		
_PRINT_HEX_BYTE:
			PUSH	AF					;Save registers
            PUSH    BC
            LD		B,A					;Save for low nibble
            RRCA						;Rotate high nibble into low nibble
			RRCA
			RRCA
			RRCA
            CALL    _PRINT_HEX_NIB		;Print high nibble
            LD		A,B					;Restore for low nibble
            CALL    _PRINT_HEX_NIB		;Print low nibble
            POP     BC					;Restore registers
            POP		AF
			RET
			
;***************************************************************************
;PRINT_HEX_WORD
;Function: Prints the four hex digits of a word to the serial line from HL
;***************************************************************************
_PRINT_HEX_WORD:     
			PUSH 	HL
            PUSH	AF
            LD		A,H
			CALL	_PRINT_HEX_BYTE		;Print high byte
            LD		A,L
            CALL    _PRINT_HEX_BYTE		;Print low byte
            POP		AF
			POP		HL
            RET			
			