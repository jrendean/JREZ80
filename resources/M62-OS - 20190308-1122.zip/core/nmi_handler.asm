;**************************************
; M62-OS
;**************************************
; nmi_handler.asm - M62-OS NMI Handler
;**************************************
; (C)Copyright 2019
; By Peter Murray
;**************************************

; I plan to have a menu show up when NMI is pressed, this will give a choice to return to OS, BIOS, or back to program.

_NMI_MSG:		.BYTE	"\r\n- Application suspended -\r\n",EOS


NMI_HANDLER:	PUSH	AF
				PUSH	BC
				PUSH	DE
				PUSH	HL
				LD		HL, APP_STATUS
				LD		A, (HL)				; Get application status
				CP		$02
				JP		NZ, _NMI_CONT		; if not $02 (running) then ignore NMI and go back
				LD 		HL, _NMI_MSG
				CALL	_PUTS
				LD		HL, APP_STATUS
				LD		A, $03
				LD		(HL), A				; Set application status to suspended
				
				; Need to do propper state preservation code here
				
				POP		HL
				POP		DE
				POP		BC
				POP		AF
				JP		CMD_LINE			; Go back to CLI
_NMI_CONT:		POP		HL
				POP		DE
				POP		BC
				POP		AF
				RETN						; Return from NMI