;**************************************
; M62-OS
;**************************************
; bin_rx.asm - M62-OS Application RX
;**************************************
; (C)Copyright 2019
; By Peter Murray
;**************************************

TIMEOUT:	.EQU	 		$FF ; timeout value for waiting for character $FF is about 13 seconds
BINRX_1:	.BYTE 			"\r\nReady to receive...\r\n",EOS
BINRX_2:	.BYTE 			"\r\nApplication is now loaded.\r\n",EOS
BINRX_3:	.BYTE 			"Done\r\n",EOS

_BINARY_RECEIVE:
			LD		HL, APP_LOC			; Point HL to Application space
			PUSH	HL					; push the value we just got into the stack
			LD		D, H				; put the chosen address into DE
			LD		E, L
			LD 		HL,BINRX_1			; Print ready messages 
			CALL    _PUTS
			CALL	_UART_RX			; wait indefinitely for the first character
			JP		B_JUMP_IN
B_CHECK_RX:
			IN		A, (UART5)			;Fetch the control register
			BIT 	0, A				;Bit will be set if UART is ready to receive
			JP		NZ, B_DATA_READY	;Data is waiting
			INC		B					;increment timout count
			LD		A, B
			CP		TIMEOUT				; have we reached the timeout?
			JP		NC, B_DONE 			; if yes, then we are done
			JP		B_CHECK_RX			; go and check again.
B_DATA_READY:
			IN      A,(UART0)			;Receive character in UART to A
B_JUMP_IN:
			POP		HL
			LD		(HL), A

			LD		A, '.'
			CALL	PUTC
			
			INC		HL
			PUSH	HL
			LD		B, $00				; reset timout counter
			JP		B_CHECK_RX			; go check for next character
B_DONE:
			LD 		HL,BINRX_3			;Print some messages 
			CALL    PUTS
B_DONE2:
			LD 		HL,BINRX_2			;Print some messages 
			CALL    PUTS

			LD		HL, APP_STATUS
			LD		A, $01
			LD		(HL), A				; Set application status to loaded
			
			POP		HL
			JP		CMD_LINE