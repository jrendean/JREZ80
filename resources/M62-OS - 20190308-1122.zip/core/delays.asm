;*****************************
; delays.asm
;*****************************
; Created by Don Prefontaine
;*****************************

;********************************************************************************************
; loopDELAY	- Performs a loop delay based on the value loaded in HL
;********************************************************************************************
; Entry: 	
;			HL : loop size, this determines the length of the delay (values in m62_defs.asm)
;			C  : Seperator character to use
;********************************************************************************************
_loopDELAY:  				
			NOP
			NOP
			DEC 		L
			JP 			NZ, loopDELAY
			DEC			H
			JP 			NZ, loopDELAY
			RET            

; constant name   | rough delay time
;-----------------+---------------------------------------------------------------------------
; DELAY_FIFTY     |	50us
; DELAY_HUNDRED   |	100us
; DELAY_THOUSAND  |	1000us
; DELAY_HALF64K   |	179ms
; DELAY_FULL64K   |	360ms
; DELAY_SCROLL    |	9ms. Used to slow-scroll an LCD display.
; DELAY_DINCER    |	1.6ms. Used by Dincer Aydin for one of his LCD initialization routines.
;-----------------+---------------------------------------------------------------------------
; Dincer's example code is found here: http://www.dinceraydin.com/lcd/z80example.htm


;********************
; Coding example
;********************
;			LD			HL,	DELAY_DINCER
;			CALL		loopDELAY