;***********************************************
; M62-OS Hardware Defines
;***********************************************
; hw_defs.asm - Hardware definitions for M62-OS
;***********************************************

UART_BASE:			.EQU	$08			; Base address for the UART
EXP1_BASE:			.EQU	$C0			; Expansion Card 1 base address

BANK_0:				.EQU	$0000		; Bank 0
BANK_1:				.EQU	$4000		; Bank 1
BANK_2:				.EQU	$8000		; Bank 2
BANK_3:				.EQU	$C000		; Bank 3
