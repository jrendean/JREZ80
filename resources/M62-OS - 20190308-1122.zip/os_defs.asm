;***********************************************
; M62-OS Defines
;***********************************************
; os_defs.asm - Definitions for values used by the OS
;***********************************************

BUFF_BASE:			.EQU	$7000
CMD_BUFF:			.EQU	BUFF_BASE					; Command buffer location
CMD_SIZE:			.EQU	30							; command buffer size
EXP_LOC:			.EQU	BUFF_BASE+CMD_SIZE			; Expansion Card location
PARSE_CNT:			.EQU	EXP_LOC+1					; Parse count (# parameters)
PARSE_TBL:			.EQU	PARSE_CNT+1					; Parse Pointer Table
; PARSE_CNT = Count of parameter strings
; PARSE_TBL = Location of beginging of Parse Table (SSx)
; | # substrings | SS1 PTR | SS2 PTR | ... | SSn PTR |

APP_STATUS			.EQU	$0007						; Application status byte location. $00:empty, $01:loaded, $02:running, $03:suspended

APP_LOC				.EQU	$0100						; Location of start of application space

; Console values
EOS:				.EQU	$00							; Null Character (End Of String)
CR:					.EQU	$0D							; Carriage Return
LF:					.EQU	$0A							; Line Feed

HOME_STRING:		.BYTE	ESC,"[f",EOS
CLEAR_STRING:		.BYTE	ESC,"[2J",EOS				; Printing this screen to the terminal will clear the screen and return the cursor to the top left of the screen.
BS:					.EQU	$08							; Backspace character
ESC:				.EQU	$1B							; Escape character


; Delay values
DELAY_FIFTY:		.EQU	0105h						; 50us
DELAY_HUNDRED:		.EQU	0110h						; 100us
DELAY_THOUSAND:		.EQU	01B6h						; 1000us
DELAY_HALF64K:		.EQU	7FFFh						; 179ms
DELAY_FULL64K:		.EQU	0FFFFh						; 360ms
DELAY_SCROLL:		.EQU	3FFFh						; 89ms. Used to slow-scroll an LCD display.
DELAY_DINCER:		.EQU	0220h						; 1.6ms. Used by Dincer Aydin for one of his LCD initialization routines.
