;************************************
; M62-OS
;************************************
; m62-os.asm - Main OS assembly file
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************
.ORG			$4000						; This starts in Bank 1
OS_INIT:		DI							; Disable Interrupts
				LD		SP, $7FFF			; Set up the stack pointer (actually resets it as we are starting fresh)
				LD		A, $01
				LD		C, $00
				OUT		(C), A				; Switch Bank 0 to RAM
				LD		BC, $00FF			; Number of bytes to copy
				LD		HL, $7000			; Where to copy from
				LD		DE, $0000			; Where to copy to
				LDIR						; Copy vector image into bank 0 RAM
				JP		OS_START			; Jump to the start of the OS
				
VERSION_TXT:	.BYTE	"\r\nM62-OS v1.1.2\r\n", EOS
DATE_TXT:		.BYTE	"March 7 2019\r\n", EOS
COPYRIGHT_TXT:	.BYTE	"(C)2019 Peter Murray\r\n", EOS
HELP_TXT:		.BYTE	"help or ? for list of commands\r\n", EOS
				
OS_START:
				CALL	_CLRSCR				
				LD		HL, VERSION_TXT
				CALL	_PUTS
				LD		HL, DATE_TXT
				CALL	_PUTS
				LD		HL, COPYRIGHT_TXT
				CALL	_PUTS
				LD		HL, HELP_TXT
				CALL	_PUTS
				CALL	EXP1_INIT
			
				JP		START_CLI
			
FOREVER_LOOP:	HALT
				JP	FOREVER_LOOP			; For now in case we didn't catch this.

#INCLUDE	"core/nmi_handler.asm"			; M62-OS NMI Handler
INT_HANDLER:	RETI						; For now we just return when interrupted

#INCLUDE		"os_defs.asm"
#INCLUDE		"hw_defs.asm"


;***************************
; M62-OS Routine Jump Table
;***************************
.ORG $5000 ; M62-OS Routine Jump Table start, do not change this
#INCLUDE	"core/jump_table.asm"			; M62-OS Jump table


#INCLUDE	"core/cli.asm"					; Command Line Interface


; Routines section
#INCLUDE	"core/console_utils.asm"		; Console utility routines
#INCLUDE	"core/strings.asm"				; String routines
#INCLUDE	"core/console.asm"				; Console routines
#INCLUDE	"core/delays.asm"				; Delay routines
#INCLUDE	"core/math.asm"					; Math routines

; Driver section
.ORG			$6000
#INCLUDE	"drivers/16c550uart.asm"		; 16C550 UART Driver
#INCLUDE	"drivers/exp_1.asm"				; Expansion Card 1 Driver

;**********************************************************************************************
; Vector Image
;**********************************************************************************************
; This is copied to RAM at bank 0, it will redirect interrupts to the OS.
;**********************************************************************************************
; When assembled, this will reside in the buffer area, we don't use the buffer area until
; after we have copied this to bank 0 so it doesn't cause any harm, but if we try to
; re-initialize the OS after cold boot, this vector image will be corrupted and cause an
; invalid vector table to be copied to Bank 0. Therefore the OS should be reloaded from storage
; after a cold boot.
;**********************************************************************************************
.ORG			$7000						; Image of what is needed to be copied to bank 0
				DI							; Disable Interrupts
				LD		SP, $7FFF			; Set up the stack pointer
				JP		OS_START			; Jump to start of the OS
.ORG			$7038						; Vector for INT
				JP		INT_HANDLER
.ORG			$7066						; Vector for NMI
				JP		NMI_HANDLER
.ORG			$70FF						; Should not get here, but in case it does...
				HALT
				
.END
