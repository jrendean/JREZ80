;**************************************
; M62-OS
;**************************************
; test_app.asm - Test Application
;**************************************
; (C)Copyright 2019
; By Peter Murray
;**************************************
.ORG $0100						; start vector

APP_START:		LD		HL, TEST_X
				CALL	PUTS
				JP		RETURN_TO_OS
				
APP_LOOP:		JP		APP_LOOP
				HALT


TEST_X:			.BYTE	"\r\nTest X Application!\r\n",EOS

#INCLUDE		"../os_defs.asm"
#INCLUDE		"../hw_defs.asm"
#INCLUDE		"../routine_entry.asm"

;**********************************************************************************
; RFS_CHECK	- Checks if the current device is ROMFS
;**********************************************************************************
; Entry: 	
;			none
; Exit: 	
;			Z flag is set if it is ROMFS, clear otherwise
;*****************************************************************************
RFS_CHECK:		LD		HL, BANK_2
				LD		A, (HL)
				CP		'R'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'O'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'M'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'F'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'S'
				RET
				
.end
