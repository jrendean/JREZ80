;**************************************
; M62-OS
;**************************************
; ROMFStest.asm - ROMFS Test Application
;**************************************
; (C)Copyright 2019
; By Peter Murray
;**************************************
.ORG $0100						; start vector

APP_START:		LD		HL, APP_NAME
				CALL	PUTS
				LD		A, $00
				CALL	RFS_DO_TEST
				LD		A, $01
				CALL	RFS_DO_TEST
				LD		A, $02
				CALL	RFS_DO_TEST
				LD		A, $03
				CALL	RFS_DO_TEST

				JP		RETURN_TO_OS

RFS_DO_TEST:	PUSH	AF
				LD		HL, STR_TEST
				CALL	PUTS
				CALL	PRINT_HEX_BYTE
				
				POP		AF
				CALL	EXP1_CHIP
				
				LD		HL, RFS_SEEK
				CALL	PUTS
				
				CALL	RFS_CHECK
				JP		Z, RFS_TRUE
				LD		HL, STR_FALSE
				CALL	PUTS
				RET
RFS_TRUE:		LD		HL, STR_TRUE
				CALL	PUTS
				LD		HL, STR_SIZE
				CALL	PUTS
				LD		HL, RFS_SIZE
				LD		A, (HL)
				CALL	PRINT_HEX_BYTE
				LD		HL, STR_LBL
				CALL	PUTS
				LD		HL, RFS_LABEL	; Print the label
				CALL	PUTS
				CALL	PRINT_NEW_LINE
				RET
				
;EXP1_CHIP

APP_NAME:		.BYTE	"\r\nROMFS Test Application!\r\n",EOS
STR_TEST:		.BYTE	"\r\nTesting Chip ",EOS
RFS_SEEK:		.BYTE	" ROMFS Signature = ",EOS
STR_TRUE:		.BYTE	"True\r\n",EOS
STR_FALSE:		.BYTE	"False\r\n",EOS
STR_SIZE:		.BYTE	"\r\nSize = ",EOS
STR_LBL:		.BYTE	"\r\nLabel = ",EOS
				
#INCLUDE		"../os_defs.asm"
#INCLUDE		"../hw_defs.asm"
#INCLUDE		"../routine_entry.asm"

RFS_IDENT:		.EQU	BANK_2
RFS_TYPE:		.EQU	BANK_2 + $05
RFS_VER:		.EQU	BANK_2 + $06
RFS_ATTRIBS:	.EQU	BANK_2 + $08
RFS_SIZE:		.EQU	BANK_2 + $09
RFS_PAGE:		.EQU	BANK_2 + $0A
RFS_LABEL:		.EQU	BANK_2 + $0B
RFS_FILENAME:	.EQU	BANK_2 + $0A
RFS_DESC:		.EQU	BANK_2 + $0B


;**********************************************************************************
; RFS_CHECK	- Checks if the current device is ROMFS
;**********************************************************************************
; Entry: 	
;			none
; Exit: 	
;			Z flag is set if it is ROMFS, clear otherwise
;*****************************************************************************
RFS_CHECK:		LD		HL, RFS_IDENT
				LD		A, (HL)
				CP		'R'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'O'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'M'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'F'
				RET		NZ
				INC		HL
				LD		A, (HL)
				CP		'S'
				RET


; EXP1_CHIP:	Selects the chip stated in A, preserved extended address
EXP1_CHIP:		LD		B, A
				LD		HL, EXP_LOC
				LD		C, (HL)
;				LD		C, EXP1_BASE
				IN		A, (C)
				LD		C, $1F
				AND		C
				SLA		B
				SLA		B
				SLA		B
				SLA		B
				SLA		B
				OR		B
				LD		C, EXP1_BASE
				OUT		(C), A				; Select chip and preserve extended address.
				RET
				
; EXP1_ADDR:	Sets the extended address stated in A, preserves chip select
EXP1_ADDR:		LD		C, $1F
				AND		C
				LD		B, A
				LD		HL, EXP_LOC
				LD		C, (HL)
				IN		A, (C)
				LD		C, $E0
				AND		C
				OR		B
				LD		HL, EXP_LOC
				LD		C, (HL)
				OUT		(C), A				; Select chip and preserve extended address.
				RET
				
; EXP1_SET:		Sets chip select and extended address stated in A
EXP1_SET:		LD		HL, EXP_LOC
				LD		C, (HL)
				OUT		(C), A				; Reset chip selection and extended address.
				RET



.end
