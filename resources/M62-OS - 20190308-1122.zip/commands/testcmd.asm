;************************************
; M62-OS
;************************************
; testcmd.asm - test commands
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************


CLI_TEST:
			PUSH	AF
			LD		DE, PARSE_CNT
			LD		A, (DE)
			LD		DE, PARSE_TBL
			LD		HL, CMD_BUFF
CT_LOOP:	CP		$00					; check for no params left
			JP		Z, CT_DONE			; Return to command line
			CALL	PUTS
			CALL	PRINT_NEW_LINE			
			LD		A, (DE)
			LD		L, A
			INC		DE
			LD		A, (DE)
			LD		H, A
			INC		DE
			JP		CT_LOOP
CT_DONE:	POP		AF
			JP		CMD_LINE


CLI_TEST2:
			PUSH	AF
			LD		DE, PARSE_CNT
			LD		A, (DE)			; A holds the number of parameters there is
			CP		$00
			JP		Z, _CT2_NOPARAM		; Exit if none
			
			LD		HL, PARSE_TBL	; HL now points to the first parameter
			LD		E, (HL)
			INC		HL
			LD		D, (HL)
			EX		DE, HL
			PUSH	HL
			CALL	_PUTS			; Prints the input parameter string
			CALL	PRINT_NEW_LINE
			CALL	_STRISHEX		; check if hex string, Z set if true
			JP		NZ, _CT2_NOVPARAM ; If Z is clear then we have no valid parameters
			POP		HL
			CALL	_STRHEXVAL	; Convert string to hex, put result in BC
			LD		H, B
			LD		L, C
			CALL	PRINT_HEX_WORD
			CALL	PRINT_NEW_LINE
			JP		CMD_LINE

_CT2_NOPARAM:
			LD		HL, CT2_NO
			CALL	_PUTS
			JP		CMD_LINE
_CT2_NOVPARAM:
			LD		HL, CT2_NOV
			CALL	_PUTS
			JP		CMD_LINE
			
CT2_NO:		.BYTE	"\r\nNo parameters given\r\n",EOS
CT2_NOV:	.BYTE	"\r\nNo valid hex parameter given\r\n",EOS
