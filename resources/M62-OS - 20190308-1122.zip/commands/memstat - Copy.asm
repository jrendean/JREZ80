;************************************
; M62-OS
;************************************
; memstat.asm - Memory Statistic
;************************************
; (C)Copyright 2019
; By Peter Murray
; Parts by Don Prefontaine
;************************************

_mstext_0:		.BYTE	"\r\n",ESC,"[7m Memory Statistics: ",ESC,"[0m\r\n",EOS
_msbank:		.BYTE	"Bank ",EOS
_mschip:		.BYTE	"Chip ",EOS
_msram:			.BYTE	": RAM\r\n",EOS
_msrom:			.BYTE	": ROM\r\n",EOS
_msempty:		.BYTE	": ",ESC,"[7mEMPTY",ESC,"[0m\r\n",EOS
;_msempty:		.BYTE	": EMPTY\r\n",EOS
_msdone:		.BYTE	"\r\n---- End of Memory Statistics ----\r\n",EOS
_msnocard:		.BYTE	"No Expansion card present\r\n",EOS

MEMSTAT:
				LD		HL, _mstext_0
				CALL	_PUTS
				
				LD		HL, EXP_LOC
				LD		C, (HL)
				LD		A, $00
				CP		C
				JP		Z, _MS_NOEXP_
				
				LD		A, 0
				CALL	_CHECKCHIP
				LD		A, 1
				CALL	_CHECKCHIP
				LD		A, 2
				CALL	_CHECKCHIP
				LD		A, 3
				CALL	_CHECKCHIP
				LD		A, 4
				CALL	_CHECKCHIP
				LD		A, 5
				CALL	_CHECKCHIP
				LD		A, 6
				CALL	_CHECKCHIP
				LD		A, 7
				CALL	_CHECKCHIP
			
				LD		HL, _msdone
				CALL	_PUTS
				JP		CMD_LINE
			
_CHECKCHIP:		; checks chip in chip location in A
				LD		HL, _mschip
				CALL	_PUTS
				LD		B,'0'
				ADD		A,B				; Convert byte to ASCII
				CALL	_PUTC			; print it
				SLA		A
				SLA		A
				SLA		A
				SLA		A
				SLA		A
				CALL	EXP1_SET
				
				LD		HL, $8000		; Bank 2 (where exp_1 memory resides)
				LD		D, (HL)			; Copy first byte into D to keep it safe
; Code from here on is modified from Don's code

		LD	A,	$55		; Put first test pattern ($55) in A.
		LD	(HL),	A   ; Store first test pattern at HL address.
		LD	A,	(HL)	; Read what was stored.
		CP	$55			; Did the original value change to $55?
		JP	NZ,	_MSROM		; No, this is ROM.
		LD	A,	$AA		; Yes. Test again with a different test pattern ($AA).
		LD	(HL),	A   
		LD	A,	(HL)
		CP	$AA 		; Did the original value change to $AA?
		JP NZ,	_MSROM 	; No, this is ROM.
		JP _MSRAM			; Yes, this is RAM.
_MSROM:
		LD	A,	$7E		; Reading a byte at a non-selected bank yields $7E.
		LD	(HL),	A	; Put $7E into test location. Can't put it into ROM.
		LD	A,	(HL)	; Read back the test location.
		CP	$7E			; Is it a non-selected bank?
		JP Z, _MSNONE		; Yes, jump to NONE0 and display NONE message.
		LD	HL,	_msrom	; No, display message: ROM.
		CALL _PUTS
		RET
_MSNONE:	
		LD	HL, _msempty	; Display message: Empty.
		CALL _PUTS
		RET
_MSRAM:	
		LD	HL,	_msram	; Display message: RAM.
		CALL _PUTS
		LD		HL, $8000		; Bank 2 (where exp_1 memory resides)
		LD	(HL), D			; Restore original byte
		RET
; Back to my code :)
_MS_NOEXP_:		LD		HL, _msnocard
				CALL	_PUTS
				JP		CMD_LINE
