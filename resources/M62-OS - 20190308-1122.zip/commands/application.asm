;************************************
; M62-OS
;************************************
; application.asm - app command
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************

APP_COMMAND:
			LD		HL, PARSE_CNT
			LD		A, $00
			CP		(HL)
			JP		Z, APP_NOPARAM		; If no parameters specified then show help for restart command

			LD		DE, PARSE_TBL		
			LD		A, (DE)
			LD		L, A
			INC		DE
			LD		A, (DE)				; point HL to first parameter
			LD		H, A
			LD		DE, AST_PARAM			; Check for status parameter
			CALL	_STRCMP
			JP		Z, APP_STAT  		; Show application status			
			LD		DE, BRX_PARAM
			CALL	_STRCMP
			JP		Z, _BINARY_RECEIVE
			LD		DE, EXE_PARAM
			CALL	_STRCMP
			JP		Z, EXEC_APP
; CLEAR_PARAM
			LD		DE, CLEAR_PARAM
			CALL	_STRCMP
			JP		Z, APP_CLEAR

			; no valid parameter was found:
			LD		HL, APP_IVLD
			CALL	PUTS
			JP		CMD_LINE
APP_NOPARAM:							; we get here too if a non-valid parameter exists
			LD		HL, APP_HELP
			CALL	PUTS
			JP		CMD_LINE
APP_STAT:
			LD		HL, APP_STATUS
			LD		A, (HL)				; Get application status
			CP		$00
			JP		Z, APP_EMPTY		; if $00 (empty) then we can't execute it
			CP		$01
			JP		Z, APP_LDED			; if $01 it is loaded and not suspended
			CP		$03
			JP		Z, APP_SUSP			; if $03 it is suspended
			LD		HL, APP_INVLD		; if here, then we have an invalid status code
			CALL	PUTS
			JP		CMD_LINE
APP_LDED	LD		HL, APP_LDSTR
			CALL	PUTS
			JP		CMD_LINE
APP_EMPTY:	LD		HL, APP_NOSTR
			CALL	PUTS
			JP		CMD_LINE
APP_SUSP:	LD		HL, APP_SUSTR
			CALL	PUTS
			JP		CMD_LINE
APP_CLEAR:	LD		HL, APP_STATUS
			LD		A, $00
			LD		(HL), A				; Set application status to Empty
	; CLEAR APPLICATION MEMORY HERE, IT ONLY CLEARS THE STATUS AT THE MOMENT!
			LD		HL, APP_CLRD
			CALL	PUTS
			JP		CMD_LINE


_E_A_STR1:	.BYTE	"\r\nNo Application loaded.\r\n",EOS
EXEC_APP:
			LD		HL, APP_STATUS
			LD		A, (HL)				; Get application status
			CP		$00
			JP		Z, E_A_FAIL			; if $00 (empty) then we can't execute it
			LD		HL, APP_STATUS
			LD		A, $02
			LD		(HL), A				; Set application status to running
			JP		APP_LOC				; Jump to the application
E_A_FAIL:	LD		HL, _E_A_STR1
			CALL	PUTS
			JP		CMD_LINE

; Strings used in commands

APP_IVLD:	.BYTE	"\r\nInvalid parameter!",EOS
APP_INVLD:	.BYTE	"\r\nInvalid application status detected!",EOS
APP_CLRD:	.BYTE	"\r\nApplication space has been cleared.",EOS
APP_NOSTR:	.BYTE	"\r\nNo application loaded",EOS
APP_LDSTR:	.BYTE	"\r\nApplication is loaded",EOS
APP_SUSTR:	.BYTE	"\r\nApplication is suspended",EOS
APP_HELP:	.BYTE	"\r\n",ESC,"[7m app usage: ",ESC,"[0m\r\n"
			.BYTE	"  app status    = Shows the status of the application space\r\n"
			.BYTE	"  app resume    = Resumes a suspeded application\r\n"
			.BYTE	"  app receive   = Receives an application via binary transfer\r\n"
			.BYTE	"  app clear	 = Removes application from application space\r\n"
			.BYTE	"  app execute   = Executes a loaded application\r\n",EOS

