;************************************
; M62-OS
;************************************
; exp_1.asm - Expansion Card 1 driver
;************************************
; (C)Copyright 2019
; By Peter Murray
;************************************

				
; EXP1_CHIP:	Selects the chip stated in A, preserved extended address
EXP1_CHIP:		LD		B, A
				LD		HL, EXP_LOC
				LD		C, (HL)
;				LD		C, EXP1_BASE
				IN		A, (C)
				LD		C, $1F
				AND		C
				SLA		B
				SLA		B
				SLA		B
				SLA		B
				SLA		B
				OR		B
				LD		C, EXP1_BASE
				OUT		(C), A				; Select chip and preserve extended address.
				RET
				
; EXP1_ADDR:	Sets the extended address stated in A, preserves chip select
EXP1_ADDR:		LD		C, $1F
				AND		C
				LD		B, A
				LD		HL, EXP_LOC
				LD		C, (HL)
				IN		A, (C)
				LD		C, $E0
				AND		C
				OR		B
				LD		HL, EXP_LOC
				LD		C, (HL)
				OUT		(C), A				; Select chip and preserve extended address.
				RET
				
; EXP1_SET:		Sets chip select and extended address stated in A
EXP1_SET:		LD		HL, EXP_LOC
				LD		C, (HL)
				OUT		(C), A				; Reset chip selection and extended address.
				RET

_CRD_SRCH:		.BYTE	"\r\nSearching for Expansion Card...",EOS
_CRD_DONE:		.BYTE	" None found\r\n",EOS

EXP1_INIT:
				LD		HL, _CRD_SRCH
				CALL	_PUTS
				LD		A, $C0
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C1
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C2
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C3
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C4
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C5
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C6
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
				LD		A, $C7
				CALL	_CRD_PRB
				CP		B
				JP		Z, _FID_EXP_		; If B and A match then we have a winner!
; if we get here, we didnt find any
				LD		HL, _CRD_DONE
				CALL	_PUTS
				RET
_FID_EXP_:		LD		HL, EXP_LOC
				LD		(HL), A				; Put the location in the buffer
				LD		B, A
				LD		A, '['
				CALL	_PUTC
				LD		HL, EXP_LOC				
				LD		A, (HL)
				CALL	_PRINT_HEX_BYTE
				LD		A, ']'
				CALL	_PUTC
; initialize the card
				LD		A, $00
				LD		HL, EXP_LOC
				LD		C, (HL)
				OUT		(C), A				; Reset chip selection and extended address.


				RET

_CRD_PRB:		LD		C, A
				LD		B, A
				OUT		(C), A				; Write to expansion register
				IN		A,(C)				; Read from expansion register
				CP		B					; Compare written and read values
				JP		NZ,_CRD_PRB_NO		; if they don't return 00 in A
				RET
_CRD_PRB_NO:	LD		B, $00
				RET
